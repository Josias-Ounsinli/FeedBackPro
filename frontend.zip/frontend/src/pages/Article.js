import { Helmet } from 'react-helmet-async';
import { useParams } from 'react-router-dom';
import { useState } from 'react';
// @mui
import { Container, Stack, Typography, TextField, Button , Rating} from '@mui/material';
import { styled } from '@mui/material/styles';
// components
import { ProductSort, ProductList, ProductCartWidget, ProductFilterSidebar } from '../sections/@dashboard/products';

// mock
import {products} from '../_mock/products';
import ShopProductCard from '../sections/@dashboard/products/Product';

// ----------------------------------------------------------------------
const StyledRoot = styled('div')({
    display: 'flex',
    minHeight: '100%',
    overflow: 'hidden',
  });
  
const Main = styled('div')(({ theme }) => ({
    flexGrow: 1,
    overflow: 'auto',
    minHeight: '100%',
    marginTop: '50px',
    paddingBottom: theme.spacing(10),
    [theme.breakpoints.up('lg')]: {
        paddingTop: theme.spacing(2),
        paddingLeft: theme.spacing(2),
        paddingRight: theme.spacing(2),
    },
}));

export default function Article() {
  const {id} = useParams()
  console.log(id)
  const [openFilter, setOpenFilter] = useState(false);
  const [state, setState] = useState({
    'title': '',
    'desc': '',
    'star': 0
  })
  const [product, setProduct] = useState(products.filter(data => data.id.toString() === id))

  const handleOpenFilter = () => {
    setOpenFilter(true);
  };

  const handleCloseFilter = () => {
    setOpenFilter(false);
  };

  const handleSubmit = (event) => {
    // Call service
  }

  const handleChange = (event) => {
    const name = event.target.name
    const value = event.target.value
    setState({...state, [name] : value})
  }

  return (
    <>
    <StyledRoot>
      {/* <Header /> */}

        <Main>
        <Helmet>
            <title> Dashboard: Article </title>
        </Helmet>

        <div
            style={{
                padding: '100px'
            }}
        >
            <Typography variant="h4" sx={{ mb: 5 }}>
                Produits {product[0].name}
            </Typography>
            <Typography sx={{ mb : 5 }}>
                Ce t-shirt en coton est parfait pour un usage quotidien.
            </Typography>

            <ShopProductCard product={product[0]} />

            <div style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '20px',
                marginTop: '20px'
            }}>
                <Rating 
                    name="star"
                    value={state.star}
                    onChange={handleChange}
                />
                <TextField
                    id="outlined-multiline-flexible"
                    label="Titre"
                    name='title'
                    maxRows={4}
                    onChange={handleChange}
                />
                <TextField
                    id="outlined-multiline-flexible"
                    label="Commentaire"
                    name='desc'
                    multiline
                    maxRows={4}
                    rows={7}
                    onChange={handleChange}
                />
                <Button 
                    variant="contained"
                    align='rigth'
                    style={{
                        width: '150px'
                    }}
                    onClick={handleSubmit}
                >Commenter</Button>
            </div>
        </div>
        </Main>
      </StyledRoot>
    </>
  );
}
