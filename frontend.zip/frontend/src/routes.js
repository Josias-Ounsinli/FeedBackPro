import { Navigate, useRoutes } from 'react-router-dom';
// layouts
import DashboardLayout from './layouts/dashboard';
import SimpleLayout from './layouts/simple';
//
import BlogPage from './pages/BlogPage';
import UserPage from './pages/UserPage';
import LoginPage from './pages/LoginPage';
import Page404 from './pages/Page404';
import ProductsPage from './pages/ProductsPage';
import DashboardAppPage from './pages/DashboardAppPage';
import Article from './pages/Article';
import Article1 from './pages/Article1';
import Article2 from './pages/Article2';
import ProductsPage1 from './pages/ProductsPage1';
import ProductsPage2 from './pages/ProductsPage2';

// ----------------------------------------------------------------------

export default function Router() {
  const routes = useRoutes([
    {
      path: '/dashboard',
      element: <DashboardLayout />,
      children: [
        { element: <Navigate to="/dashboard/app" />, index: true },
        { path: 'app', element: <DashboardAppPage name='' /> },
        { path: 'app/:name', element: <DashboardAppPage /> },
        { path: 'user', element: <UserPage /> },
        { path: 'blog', element: <BlogPage /> },
      ],
    },
    { path: 'products',
      element: <ProductsPage />,
    },
    { path: 'products/:id',
      element: <Article /> 
    },
    { path: 'products1',
      element: <ProductsPage1 />,
    },
    { path: 'products1/:id',
      element: <Article1 /> 
    },
    { path: 'products2',
      element: <ProductsPage2 />,
    },
    { path: 'products2/:id',
      element: <Article2 /> 
    },
    {
      path: 'login',
      element: <LoginPage />,
    },
    {
      element: <SimpleLayout />,
      children: [
        { element: <Navigate to="/dashboard/app" />, index: true },
        { path: '404', element: <Page404 /> },
        { path: '*', element: <Navigate to="/404" /> },
      ],
    },
    {
      path: '*',
      element: <Navigate to="/404" replace />,
    },
  ]);

  return routes;
}
